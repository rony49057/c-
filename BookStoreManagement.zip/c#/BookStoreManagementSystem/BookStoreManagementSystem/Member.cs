﻿using System;
using System.Data;
using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    public partial class Member : Form
    {
        private DataAccess Da { get; set; }
        private string customerName;

        public Member()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.dgvCart.AllowUserToAddRows = false;
            this.PopulateGridView();
            this.AutoIdGenerate();
        }

        private void Member_Load(object sender, EventArgs e)
        {
            this.dgvProduct.ClearSelection();
            this.AutoIdGenerate();
            this.dgvCart.Rows.Clear();
            this.txtTotalAmount.Clear();
        }

        private void PopulateGridView(string sql = "SELECT * FROM Product;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                this.dgvProduct.AutoGenerateColumns = false;
                this.dgvProduct.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void txtMemberSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = $"SELECT * FROM Product WHERE ProductName LIKE '{this.txtMemberSearch.Text}%' OR ProductId LIKE '{this.txtMemberSearch.Text}%' OR Catagory LIKE '{this.txtMemberSearch.Text}%';";
            this.PopulateGridView(sql);
        }

        private void dgvProduct_DoubleClick(object sender, EventArgs e)
        {
            if (this.dgvProduct.CurrentRow != null)
            {
                this.txtMemberProductId.Text = this.dgvProduct.CurrentRow.Cells[0].Value?.ToString() ?? "";
                this.txtMemberProductName.Text = this.dgvProduct.CurrentRow.Cells[1].Value?.ToString() ?? "";
                this.txtMemberPrice.Text = this.dgvProduct.CurrentRow.Cells[2].Value?.ToString() ?? "";
                this.dgvProduct.ClearSelection();
            }
        }

        private void btnAddCart_Click(object sender, EventArgs e)
        {
            try
            {
                if (!IsValid())
                {
                    MessageBox.Show("Please fill in all the fields.");
                    return;
                }

                string id = txtMemberProductId.Text;
                string name = txtMemberProductName.Text;
                string quantityStr = txtMemberQuantity.Text;
                string priceStr = txtMemberPrice.Text;

                if (!int.TryParse(quantityStr, out int quantity) || quantity <= 0)
                {
                    MessageBox.Show("Enter a valid quantity.");
                    return;
                }

                double price = Convert.ToDouble(priceStr);
                double total = quantity * price;

                int availableQty = GetAvailableQuantity(id);
                int existingQtyInCart = 0;

                foreach (DataGridViewRow row in dgvCart.Rows)
                {
                    if (row.Cells[0].Value?.ToString() == id)
                    {
                        existingQtyInCart = Convert.ToInt32(row.Cells[2].Value);
                        break;
                    }
                }

                if (quantity + existingQtyInCart > availableQty)
                {
                    MessageBox.Show($"Only {availableQty - existingQtyInCart} more available in stock.");
                    return;
                }

                bool exists = false;
                foreach (DataGridViewRow row in dgvCart.Rows)
                {
                    if (row.Cells[0].Value?.ToString() == id)
                    {
                        int updatedQty = Convert.ToInt32(row.Cells[2].Value) + quantity;
                        row.Cells[2].Value = updatedQty;
                        row.Cells[3].Value = updatedQty * price;
                        exists = true;
                        break;
                    }
                }

                if (!exists)
                {
                    dgvCart.Rows.Add(id, name, quantity, total);
                }

                UpdateQuantity(id, quantity, true);
                CalculateTotal();
                ClearAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding to cart: " + ex.Message);
            }
        }

        private void btnPaid_Click(object sender, EventArgs e)
        {
            try
            {
                string customerName = txtCustomerName.Text.Trim();
                string total = txtTotalAmount.Text;
                if (string.IsNullOrWhiteSpace(total) || total == "0.00")
                {
                    MessageBox.Show("Cart is empty.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(customerName))
                {
                    MessageBox.Show("Customer name cannot be empty.");
                    return;
                }

                if (dgvCart.Rows.Count == 0)
                {
                    MessageBox.Show("No items in cart.");
                    return;
                }

                DialogResult result = MessageBox.Show($"Confirm payment of ${total}?", "Confirm", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    string date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    

                    foreach (DataGridViewRow row in dgvCart.Rows)
                    {
                        if (row.IsNewRow) continue;

                        string pid = row.Cells[0].Value.ToString();
                        int qty = Convert.ToInt32(row.Cells[2].Value);
                        decimal itemTotal = Convert.ToDecimal(row.Cells[3].Value);

                        string sql = $"INSERT INTO SalesInfo (ProductId, SalesDate, CustomerName, TotalAmount) VALUES ('{pid}', '{date}', '{customerName}', {itemTotal.ToString().Replace(',', '.')});";
                        Da.ExecuteDMLQuery(sql);
                    }

                    MessageBox.Show("Payment successful.");
                    ClearAllFinal();
                    PopulateGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Payment error: " + ex.Message);
            }
        }

        private void btnMemberDelete_Click(object sender, EventArgs e)
        {
            if (dgvCart.SelectedRows.Count > 0)
            {
                var row = dgvCart.SelectedRows[0];
                string id = row.Cells[0].Value.ToString();
                int qty = Convert.ToInt32(row.Cells[2].Value);

                DialogResult confirm = MessageBox.Show("Remove item?", "Confirm", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    UpdateQuantity(id, qty, false);
                    dgvCart.Rows.RemoveAt(row.Index);
                    CalculateTotal();
                }
            }
            else
            {
                MessageBox.Show("Select an item to delete.");
            }
        }

        private void btnMemberClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void btnMemberBack_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void btnMemberShowProduct_Click(object sender, EventArgs e)
        {
            PopulateGridView();
        }

        private void UpdateQuantity(string id, int qty, bool reduce)
        {
            var sql = $"SELECT Quantity FROM Product WHERE ProductId='{id}';";
            var ds = Da.ExecuteQuery(sql);
            if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0][0] != DBNull.Value)
            {
                int stock = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                int newQty = reduce ? stock - qty : stock + qty;
                if (newQty >= 0)
                {
                    var updateSql = $"UPDATE Product SET Quantity={newQty} WHERE ProductId='{id}';";
                    Da.ExecuteDMLQuery(updateSql);
                    PopulateGridView();
                }
            }
        }

        private int GetAvailableQuantity(string id)
        {
            var sql = $"SELECT Quantity FROM Product WHERE ProductId='{id}';";
            var ds = Da.ExecuteQuery(sql);
            if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0][0] != DBNull.Value)
                return Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            return 0;
        }

        private void CalculateTotal()
        {
            double sum = 0;
            foreach (DataGridViewRow row in dgvCart.Rows)
            {
                if (!row.IsNewRow && row.Cells[3].Value != null)
                {
                    if (double.TryParse(row.Cells[3].Value.ToString(), out double total))
                        sum += total;
                }
            }
            txtTotalAmount.Text = sum.ToString("F2");
        }

        private void ClearAll()
        {
            txtMemberProductId.Clear();
            txtMemberProductName.Clear();
            txtMemberPrice.Clear();
            txtMemberQuantity.Clear();
            dgvProduct.ClearSelection();
        }

        private void ClearAllFinal()
        {
            dgvCart.Rows.Clear();
            txtTotalAmount.Clear();
            ClearAll();
            AutoIdGenerate();
        }

        private bool IsValid()
        {
            return !string.IsNullOrWhiteSpace(txtMemberProductId.Text) &&
                   !string.IsNullOrWhiteSpace(txtMemberProductName.Text) &&
                   !string.IsNullOrWhiteSpace(txtMemberPrice.Text) &&
                   !string.IsNullOrWhiteSpace(txtMemberQuantity.Text);
        }

        private void AutoIdGenerate()
        {
            var query = "SELECT MAX(SalesId) FROM SalesInfo;";
           
            var dt = this.Da.ExecuteQueryTable(query);
            var oldProductId = dt.Rows[0][0];
            var num = Convert.ToInt32(oldProductId);
            var newProductId = ++num;
            this.txtSalesId.Text = newProductId.ToString();
        }
    }
}
