﻿namespace BookStoreManagementSystem
{


    partial class BookShopDataSet
    {
        partial class LoginInfoDataTable
        {
        }
    }
}
