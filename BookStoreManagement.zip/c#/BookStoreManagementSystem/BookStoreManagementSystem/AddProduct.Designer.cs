﻿namespace BookStoreManagementSystem
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProduct));
            this.pnlAddProduct = new System.Windows.Forms.Panel();
            this.btnAddProductClear = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnAddProductBack = new System.Windows.Forms.Button();
            this.lblProductId = new System.Windows.Forms.Label();
            this.btnAddProductShow = new System.Windows.Forms.Button();
            this.lblProductName = new System.Windows.Forms.Label();
            this.btnAddProductDelete = new System.Windows.Forms.Button();
            this.lblProductPrice = new System.Windows.Forms.Label();
            this.btnAddProductUpdate = new System.Windows.Forms.Button();
            this.lblProductQuantity = new System.Windows.Forms.Label();
            this.btnAddProductSave = new System.Windows.Forms.Button();
            this.lblCatagory = new System.Windows.Forms.Label();
            this.txtCatagory = new System.Windows.Forms.TextBox();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.dgvProduct = new System.Windows.Forms.DataGridView();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookShopDataSet1 = new BookStoreManagementSystem.BookShopDataSet1();
            this.productTableAdapter = new BookStoreManagementSystem.BookShopDataSet1TableAdapters.ProductTableAdapter();
            this.ProductId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlAddProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAddProduct
            // 
            this.pnlAddProduct.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlAddProduct.Controls.Add(this.btnAddProductClear);
            this.pnlAddProduct.Controls.Add(this.lblSearch);
            this.pnlAddProduct.Controls.Add(this.txtSearch);
            this.pnlAddProduct.Controls.Add(this.btnAddProductBack);
            this.pnlAddProduct.Controls.Add(this.lblProductId);
            this.pnlAddProduct.Controls.Add(this.btnAddProductShow);
            this.pnlAddProduct.Controls.Add(this.lblProductName);
            this.pnlAddProduct.Controls.Add(this.btnAddProductDelete);
            this.pnlAddProduct.Controls.Add(this.lblProductPrice);
            this.pnlAddProduct.Controls.Add(this.btnAddProductUpdate);
            this.pnlAddProduct.Controls.Add(this.lblProductQuantity);
            this.pnlAddProduct.Controls.Add(this.btnAddProductSave);
            this.pnlAddProduct.Controls.Add(this.lblCatagory);
            this.pnlAddProduct.Controls.Add(this.txtCatagory);
            this.pnlAddProduct.Controls.Add(this.txtProductId);
            this.pnlAddProduct.Controls.Add(this.txtQuantity);
            this.pnlAddProduct.Controls.Add(this.txtProductName);
            this.pnlAddProduct.Controls.Add(this.txtPrice);
            this.pnlAddProduct.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAddProduct.Location = new System.Drawing.Point(0, 0);
            this.pnlAddProduct.Name = "pnlAddProduct";
            this.pnlAddProduct.Size = new System.Drawing.Size(667, 208);
            this.pnlAddProduct.TabIndex = 0;
            // 
            // btnAddProductClear
            // 
            this.btnAddProductClear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddProductClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductClear.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddProductClear.Location = new System.Drawing.Point(411, 64);
            this.btnAddProductClear.Name = "btnAddProductClear";
            this.btnAddProductClear.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductClear.TabIndex = 32;
            this.btnAddProductClear.Text = "Clear";
            this.btnAddProductClear.UseVisualStyleBackColor = false;
            this.btnAddProductClear.Click += new System.EventHandler(this.btnAddProductClear_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(461, 178);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(41, 13);
            this.lblSearch.TabIndex = 31;
            this.lblSearch.Text = "Search";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(508, 171);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(140, 20);
            this.txtSearch.TabIndex = 30;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnAddProductBack
            // 
            this.btnAddProductBack.BackColor = System.Drawing.Color.Red;
            this.btnAddProductBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddProductBack.Location = new System.Drawing.Point(556, 13);
            this.btnAddProductBack.Name = "btnAddProductBack";
            this.btnAddProductBack.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductBack.TabIndex = 29;
            this.btnAddProductBack.Text = "BACK";
            this.btnAddProductBack.UseVisualStyleBackColor = false;
            this.btnAddProductBack.Click += new System.EventHandler(this.btnAddProductBack_Click);
            // 
            // lblProductId
            // 
            this.lblProductId.AutoSize = true;
            this.lblProductId.Location = new System.Drawing.Point(29, 25);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new System.Drawing.Size(56, 13);
            this.lblProductId.TabIndex = 15;
            this.lblProductId.Text = "Product Id";
            // 
            // btnAddProductShow
            // 
            this.btnAddProductShow.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddProductShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductShow.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddProductShow.Location = new System.Drawing.Point(411, 13);
            this.btnAddProductShow.Name = "btnAddProductShow";
            this.btnAddProductShow.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductShow.TabIndex = 28;
            this.btnAddProductShow.Text = "SHOW";
            this.btnAddProductShow.UseVisualStyleBackColor = false;
            this.btnAddProductShow.Click += new System.EventHandler(this.btnAddProductShow_Click);
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(29, 59);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(75, 13);
            this.lblProductName.TabIndex = 16;
            this.lblProductName.Text = "Product Name";
            // 
            // btnAddProductDelete
            // 
            this.btnAddProductDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddProductDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductDelete.Location = new System.Drawing.Point(313, 115);
            this.btnAddProductDelete.Name = "btnAddProductDelete";
            this.btnAddProductDelete.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductDelete.TabIndex = 27;
            this.btnAddProductDelete.Text = "DELETE";
            this.btnAddProductDelete.UseVisualStyleBackColor = false;
            this.btnAddProductDelete.Click += new System.EventHandler(this.btnAddProductDelete_Click);
            // 
            // lblProductPrice
            // 
            this.lblProductPrice.AutoSize = true;
            this.lblProductPrice.Location = new System.Drawing.Point(29, 90);
            this.lblProductPrice.Name = "lblProductPrice";
            this.lblProductPrice.Size = new System.Drawing.Size(31, 13);
            this.lblProductPrice.TabIndex = 17;
            this.lblProductPrice.Text = "Price";
            // 
            // btnAddProductUpdate
            // 
            this.btnAddProductUpdate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddProductUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductUpdate.Location = new System.Drawing.Point(313, 64);
            this.btnAddProductUpdate.Name = "btnAddProductUpdate";
            this.btnAddProductUpdate.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductUpdate.TabIndex = 26;
            this.btnAddProductUpdate.Text = "UPDATE";
            this.btnAddProductUpdate.UseVisualStyleBackColor = false;
            this.btnAddProductUpdate.Click += new System.EventHandler(this.btnAddProductUpdate_Click);
            // 
            // lblProductQuantity
            // 
            this.lblProductQuantity.AutoSize = true;
            this.lblProductQuantity.Location = new System.Drawing.Point(29, 123);
            this.lblProductQuantity.Name = "lblProductQuantity";
            this.lblProductQuantity.Size = new System.Drawing.Size(46, 13);
            this.lblProductQuantity.TabIndex = 18;
            this.lblProductQuantity.Text = "Quantity";
            // 
            // btnAddProductSave
            // 
            this.btnAddProductSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddProductSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductSave.Location = new System.Drawing.Point(313, 13);
            this.btnAddProductSave.Name = "btnAddProductSave";
            this.btnAddProductSave.Size = new System.Drawing.Size(92, 45);
            this.btnAddProductSave.TabIndex = 25;
            this.btnAddProductSave.Text = "SAVE";
            this.btnAddProductSave.UseVisualStyleBackColor = false;
            this.btnAddProductSave.Click += new System.EventHandler(this.btnAddProductSave_Click);
            // 
            // lblCatagory
            // 
            this.lblCatagory.AutoSize = true;
            this.lblCatagory.Location = new System.Drawing.Point(29, 154);
            this.lblCatagory.Name = "lblCatagory";
            this.lblCatagory.Size = new System.Drawing.Size(49, 13);
            this.lblCatagory.TabIndex = 19;
            this.lblCatagory.Text = "Catagory";
            // 
            // txtCatagory
            // 
            this.txtCatagory.Location = new System.Drawing.Point(110, 145);
            this.txtCatagory.Name = "txtCatagory";
            this.txtCatagory.Size = new System.Drawing.Size(140, 20);
            this.txtCatagory.TabIndex = 24;
            // 
            // txtProductId
            // 
            this.txtProductId.Location = new System.Drawing.Point(110, 25);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.ReadOnly = true;
            this.txtProductId.Size = new System.Drawing.Size(140, 20);
            this.txtProductId.TabIndex = 20;
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(110, 115);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(140, 20);
            this.txtQuantity.TabIndex = 23;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(110, 55);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(140, 20);
            this.txtProductName.TabIndex = 21;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(110, 85);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(140, 20);
            this.txtPrice.TabIndex = 22;
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowUserToAddRows = false;
            this.dgvProduct.AllowUserToDeleteRows = false;
            this.dgvProduct.AutoGenerateColumns = false;
            this.dgvProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductId,
            this.ProductName,
            this.Price,
            this.Quantity,
            this.Catagory});
            this.dgvProduct.DataSource = this.productBindingSource;
            this.dgvProduct.Location = new System.Drawing.Point(0, 209);
            this.dgvProduct.Name = "dgvProduct";
            this.dgvProduct.ReadOnly = true;
            this.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProduct.Size = new System.Drawing.Size(666, 162);
            this.dgvProduct.TabIndex = 1;
            this.dgvProduct.DoubleClick += new System.EventHandler(this.dgvProduct_DoubleClick);
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.bookShopDataSet1;
            // 
            // bookShopDataSet1
            // 
            this.bookShopDataSet1.DataSetName = "BookShopDataSet1";
            this.bookShopDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // ProductId
            // 
            this.ProductId.DataPropertyName = "ProductId";
            this.ProductId.HeaderText = "Book Id";
            this.ProductId.Name = "ProductId";
            this.ProductId.ReadOnly = true;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "Book Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 200;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "PRICE";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            // 
            // Catagory
            // 
            this.Catagory.DataPropertyName = "Catagory";
            this.Catagory.HeaderText = "Book Type";
            this.Catagory.Name = "Catagory";
            this.Catagory.ReadOnly = true;
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 370);
            this.ControlBox = false;
            this.Controls.Add(this.dgvProduct);
            this.Controls.Add(this.pnlAddProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddProduct";
            this.Text = "AddProduct";
            this.Load += new System.EventHandler(this.AddProduct_Load);
            this.pnlAddProduct.ResumeLayout(false);
            this.pnlAddProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAddProduct;
        private System.Windows.Forms.Button btnAddProductBack;
        private System.Windows.Forms.Label lblProductId;
        private System.Windows.Forms.Button btnAddProductShow;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Button btnAddProductDelete;
        private System.Windows.Forms.Label lblProductPrice;
        private System.Windows.Forms.Button btnAddProductUpdate;
        private System.Windows.Forms.Label lblProductQuantity;
        private System.Windows.Forms.Button btnAddProductSave;
        private System.Windows.Forms.Label lblCatagory;
        private System.Windows.Forms.TextBox txtCatagory;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.DataGridView dgvProduct;
        private BookShopDataSet1 bookShopDataSet1;
        private System.Windows.Forms.BindingSource productBindingSource;
        private BookShopDataSet1TableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Button btnAddProductClear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Catagory;
    }
}