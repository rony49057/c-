﻿namespace BookStoreManagementSystem
{
    partial class ResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlResrtPassword = new System.Windows.Forms.Panel();
            this.btnResetClear = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.txtNewPass = new System.Windows.Forms.TextBox();
            this.txtResetId = new System.Windows.Forms.TextBox();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblResetId = new System.Windows.Forms.Label();
            this.pnlResrtPassword.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlResrtPassword
            // 
            this.pnlResrtPassword.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlResrtPassword.Controls.Add(this.btnResetClear);
            this.pnlResrtPassword.Controls.Add(this.btnReset);
            this.pnlResrtPassword.Controls.Add(this.BtnExit);
            this.pnlResrtPassword.Controls.Add(this.txtNewPass);
            this.pnlResrtPassword.Controls.Add(this.txtResetId);
            this.pnlResrtPassword.Controls.Add(this.lblNewPassword);
            this.pnlResrtPassword.Controls.Add(this.lblResetId);
            this.pnlResrtPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlResrtPassword.Location = new System.Drawing.Point(0, 0);
            this.pnlResrtPassword.Name = "pnlResrtPassword";
            this.pnlResrtPassword.Size = new System.Drawing.Size(530, 290);
            this.pnlResrtPassword.TabIndex = 0;
            // 
            // btnResetClear
            // 
            this.btnResetClear.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnResetClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetClear.Location = new System.Drawing.Point(203, 186);
            this.btnResetClear.Name = "btnResetClear";
            this.btnResetClear.Size = new System.Drawing.Size(75, 33);
            this.btnResetClear.TabIndex = 6;
            this.btnResetClear.Text = "Clear";
            this.btnResetClear.UseVisualStyleBackColor = false;
            this.btnResetClear.Click += new System.EventHandler(this.btnResetClear_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.LawnGreen;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(203, 145);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 35);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.Crimson;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(443, 37);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 29);
            this.BtnExit.TabIndex = 4;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // txtNewPass
            // 
            this.txtNewPass.Location = new System.Drawing.Point(147, 99);
            this.txtNewPass.Name = "txtNewPass";
            this.txtNewPass.Size = new System.Drawing.Size(131, 20);
            this.txtNewPass.TabIndex = 3;
            // 
            // txtResetId
            // 
            this.txtResetId.Location = new System.Drawing.Point(147, 63);
            this.txtResetId.Name = "txtResetId";
            this.txtResetId.Size = new System.Drawing.Size(131, 20);
            this.txtResetId.TabIndex = 2;
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPassword.Location = new System.Drawing.Point(20, 99);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(121, 21);
            this.lblNewPassword.TabIndex = 1;
            this.lblNewPassword.Text = "New Password";
            // 
            // lblResetId
            // 
            this.lblResetId.AutoSize = true;
            this.lblResetId.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetId.Location = new System.Drawing.Point(116, 63);
            this.lblResetId.Name = "lblResetId";
            this.lblResetId.Size = new System.Drawing.Size(25, 21);
            this.lblResetId.TabIndex = 0;
            this.lblResetId.Text = "Id";
            // 
            // ResetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 290);
            this.ControlBox = false;
            this.Controls.Add(this.pnlResrtPassword);
            this.Name = "ResetPassword";
            this.Text = "ResetPassword";
            this.pnlResrtPassword.ResumeLayout(false);
            this.pnlResrtPassword.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlResrtPassword;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.TextBox txtNewPass;
        private System.Windows.Forms.TextBox txtResetId;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblResetId;
        private System.Windows.Forms.Button btnResetClear;
    }
}