﻿using System;
using System.Data;
using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    public partial class AddUser : Form
    {
        private DataAccess Da { get; set; }

        public AddUser()
        {
            InitializeComponent();
            this.Da = new DataAccess();
           
        }

        private void AddUser_Load(object sender, EventArgs e)
        {
            this.PopulateGridView();
            this.AutoIdGenerate();
        }

        // Load all data
        private void PopulateGridView(string sql = "select * from LoginInfo;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                this.dgvLoginInfo.AutoGenerateColumns = false; // Set to false if you added columns manually
                this.dgvLoginInfo.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }


        // Insert user
        private void btnAddUserSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtId.Text) ||
            string.IsNullOrWhiteSpace(txtPassword.Text) ||
            string.IsNullOrWhiteSpace(txtName.Text) ||
            string.IsNullOrWhiteSpace(txtRole.Text) ||
            string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("All fields are required.");
                    return;
                }

                string sql = $"insert into LoginInfo values('{txtId.Text}','{txtPassword.Text}','{txtName.Text}','{txtRole.Text}','{txtAddress.Text}' )";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("User added successfully");
                   
                }
                else
                {
                    MessageBox.Show("Failed to add user");
                }
                this.ClearAll();
                this.AutoIdGenerate();
                this.PopulateGridView();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding user: " + ex.Message);
            }
        }

        // Update user
        private void btnAddUserUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = $"update LoginInfo set Name = '{txtName.Text}', Password = '{txtPassword.Text}', Role = '{txtRole.Text}', Address = '{txtAddress.Text}' where Id = '{txtId.Text}'";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("User updated successfully");
                    this.PopulateGridView();
                    this.ClearAll();
                }
                else
                {
                    MessageBox.Show("Update failed");
                }
                this.ClearAll();
                this.AutoIdGenerate();
                this.PopulateGridView();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating user: " + ex.Message);
            }
        }

        // Delete user
        private void btnAddUserDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = $"delete from LoginInfo where Id = '{txtId.Text}'";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("User deleted successfully");
                    this.PopulateGridView();
                    
                }
                else
                {
                    MessageBox.Show("Delete failed");
                }
                this.ClearAll();
                this.AutoIdGenerate();
                this.PopulateGridView();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting user: " + ex.Message);
            }
        }

        // Show all users
        private void btnAddUserShow_Click(object sender, EventArgs e)
        {
            this.ClearAll();
            this.PopulateGridView();
            this.AutoIdGenerate();
           
        }

        // Load selected user from grid into textboxes
       
        private void dgvLoginInfo_DoubleClick(object sender, EventArgs e)
        {

            this.txtId.Text = this.dgvLoginInfo.CurrentRow.Cells[0].Value.ToString();
            this.txtPassword.Text = this.dgvLoginInfo.CurrentRow.Cells[1].Value.ToString();
            this.txtName.Text = this.dgvLoginInfo.CurrentRow.Cells[2].Value.ToString();
            this.txtRole.Text = this.dgvLoginInfo.CurrentRow.Cells[3].Value.ToString();
            this.txtAddress.Text = this.dgvLoginInfo.CurrentRow.Cells[4].Value.ToString();
           

        }

        // Clear input fields
        private void ClearAll()
        {
            txtId.Clear();
            txtName.Clear();
            txtPassword.Clear();
            txtAddress.Clear();
            txtRole.Clear();
        }

        // Back to admin panel
        private void btnAddUserBack_Click(object sender, EventArgs e)
        {
            new Admin().Show();
            this.Hide();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            string sql = $"select * from LoginInfo where Name like '%{keyword}%' or Role like '%{keyword}%' or Id Like '%{keyword}%' or Address Like '%{keyword}%'";
            PopulateGridView(sql);
        }

        private void btnAddUserClearAll_Click(object sender, EventArgs e)
        {
            ClearAll();
            this.AutoIdGenerate();
        }

        private void AutoIdGenerate()
        {
            var query = "select max(Id) from LoginInfo ;";
            var dt = this.Da.ExecuteQueryTable(query);
            var oldId = dt.Rows[0][0];
            var num = Convert.ToInt32(oldId);
            var newId = ++num;
            this.txtId.Text = newId.ToString();
        }
    }
}
