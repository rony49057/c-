﻿using System;
using System.Data;
using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    public partial class Login : Form
    {
        private DataAccess Da { get; set; }
        public Login()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

        private void Login_FormClosed(object sender, FormClosingEventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show(
                    @"Are you want to exit?",
                    "Exit Confirmation",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.OK)
                {
                    Application.Exit(); // Cancel the close
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during closing: " + ex.Message);
            }

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userid = txtUserId.Text;
            string password = txtPassword.Text;

            DataAccess dataAccess = new DataAccess();

            // Secure SQL with parameters is better, but using raw SQL here as in your example
            string sql = $"SELECT * FROM [LoginInfo] WHERE Id = '{userid}' AND Password = '{password}';";

            try
            {
                if (string.IsNullOrWhiteSpace(txtUserId.Text) ||
                    string.IsNullOrWhiteSpace(txtPassword.Text) )
           
                {
                    MessageBox.Show("All fields are required.");
                    return;
                }
                DataTable dt = dataAccess.ExecuteQueryTable(sql);

                if (dt.Rows.Count > 0)
                {
                    string role = dt.Rows[0]["Role"].ToString().ToLower(); 
                   string name = dt.Rows[0]["Name"].ToString().ToUpper();

                    if (role == "admin")
                    {
                        MessageBox.Show($"Welcome, Admin: {name}");
                        Admin admin = new Admin();
                        admin.Show();
                        this.Hide();
                    }
                    else if (role == "member")
                    {
                        MessageBox.Show($"Welcome , Member: {name}");
                     
                        Member member = new Member();
                        member.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Unknown user role: " + role, "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkPassword.Checked)
                this.txtPassword.UseSystemPasswordChar = false;
            else
                this.txtPassword.UseSystemPasswordChar = true;
        }

        private void btnResetPass_Click(object sender, EventArgs e)
        {
            ResetPassword resetPassword = new ResetPassword();
            resetPassword.Show();
            this.Hide();
        }
    }
}
