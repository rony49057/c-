﻿using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    partial class AddUser
    {
      

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddUser));
            this.pnlAddUser = new System.Windows.Forms.Panel();
            this.btnAddUserClearAll = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnAddUserBack = new System.Windows.Forms.Button();
            this.btnAddUserShow = new System.Windows.Forms.Button();
            this.btnAddUserDelete = new System.Windows.Forms.Button();
            this.btnAddUserUpdate = new System.Windows.Forms.Button();
            this.btnAddUserSave = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.dgvLoginInfo = new System.Windows.Forms.DataGridView();
            this.loginInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookShopDataSet = new BookStoreManagementSystem.BookShopDataSet();
            this.loginInfoTableAdapter = new BookStoreManagementSystem.BookShopDataSetTableAdapters.LoginInfoTableAdapter();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlAddUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoginInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAddUser
            // 
            this.pnlAddUser.BackColor = System.Drawing.Color.LightGray;
            this.pnlAddUser.Controls.Add(this.btnAddUserClearAll);
            this.pnlAddUser.Controls.Add(this.lblSearch);
            this.pnlAddUser.Controls.Add(this.txtSearch);
            this.pnlAddUser.Controls.Add(this.btnAddUserBack);
            this.pnlAddUser.Controls.Add(this.btnAddUserShow);
            this.pnlAddUser.Controls.Add(this.btnAddUserDelete);
            this.pnlAddUser.Controls.Add(this.btnAddUserUpdate);
            this.pnlAddUser.Controls.Add(this.btnAddUserSave);
            this.pnlAddUser.Controls.Add(this.txtAddress);
            this.pnlAddUser.Controls.Add(this.txtRole);
            this.pnlAddUser.Controls.Add(this.txtName);
            this.pnlAddUser.Controls.Add(this.txtPassword);
            this.pnlAddUser.Controls.Add(this.txtId);
            this.pnlAddUser.Controls.Add(this.lblAddress);
            this.pnlAddUser.Controls.Add(this.lblRole);
            this.pnlAddUser.Controls.Add(this.lblName);
            this.pnlAddUser.Controls.Add(this.lblPassword);
            this.pnlAddUser.Controls.Add(this.lblId);
            this.pnlAddUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAddUser.Location = new System.Drawing.Point(0, 0);
            this.pnlAddUser.Name = "pnlAddUser";
            this.pnlAddUser.Size = new System.Drawing.Size(655, 210);
            this.pnlAddUser.TabIndex = 0;
            // 
            // btnAddUserClearAll
            // 
            this.btnAddUserClearAll.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddUserClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserClearAll.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddUserClearAll.Location = new System.Drawing.Point(406, 63);
            this.btnAddUserClearAll.Name = "btnAddUserClearAll";
            this.btnAddUserClearAll.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserClearAll.TabIndex = 17;
            this.btnAddUserClearAll.Text = "Clear";
            this.btnAddUserClearAll.UseVisualStyleBackColor = false;
            this.btnAddUserClearAll.Click += new System.EventHandler(this.btnAddUserClearAll_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(330, 187);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(123, 13);
            this.lblSearch.TabIndex = 16;
            this.lblSearch.Text = "Search by Name or Role";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(459, 184);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(140, 20);
            this.txtSearch.TabIndex = 15;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnAddUserBack
            // 
            this.btnAddUserBack.BackColor = System.Drawing.Color.Red;
            this.btnAddUserBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddUserBack.Location = new System.Drawing.Point(551, 12);
            this.btnAddUserBack.Name = "btnAddUserBack";
            this.btnAddUserBack.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserBack.TabIndex = 14;
            this.btnAddUserBack.Text = "BACK";
            this.btnAddUserBack.UseVisualStyleBackColor = false;
            this.btnAddUserBack.Click += new System.EventHandler(this.btnAddUserBack_Click);
            // 
            // btnAddUserShow
            // 
            this.btnAddUserShow.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddUserShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserShow.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddUserShow.Location = new System.Drawing.Point(406, 12);
            this.btnAddUserShow.Name = "btnAddUserShow";
            this.btnAddUserShow.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserShow.TabIndex = 13;
            this.btnAddUserShow.Text = "SHOW";
            this.btnAddUserShow.UseVisualStyleBackColor = false;
            this.btnAddUserShow.Click += new System.EventHandler(this.btnAddUserShow_Click);
            // 
            // btnAddUserDelete
            // 
            this.btnAddUserDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddUserDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserDelete.Location = new System.Drawing.Point(308, 114);
            this.btnAddUserDelete.Name = "btnAddUserDelete";
            this.btnAddUserDelete.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserDelete.TabIndex = 12;
            this.btnAddUserDelete.Text = "DELETE";
            this.btnAddUserDelete.UseVisualStyleBackColor = false;
            this.btnAddUserDelete.Click += new System.EventHandler(this.btnAddUserDelete_Click);
            // 
            // btnAddUserUpdate
            // 
            this.btnAddUserUpdate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddUserUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserUpdate.Location = new System.Drawing.Point(308, 63);
            this.btnAddUserUpdate.Name = "btnAddUserUpdate";
            this.btnAddUserUpdate.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserUpdate.TabIndex = 11;
            this.btnAddUserUpdate.Text = "UPDATE";
            this.btnAddUserUpdate.UseVisualStyleBackColor = false;
            this.btnAddUserUpdate.Click += new System.EventHandler(this.btnAddUserUpdate_Click);
            // 
            // btnAddUserSave
            // 
            this.btnAddUserSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddUserSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUserSave.Location = new System.Drawing.Point(308, 12);
            this.btnAddUserSave.Name = "btnAddUserSave";
            this.btnAddUserSave.Size = new System.Drawing.Size(92, 45);
            this.btnAddUserSave.TabIndex = 10;
            this.btnAddUserSave.Text = "SAVE";
            this.btnAddUserSave.UseVisualStyleBackColor = false;
            this.btnAddUserSave.Click += new System.EventHandler(this.btnAddUserSave_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(105, 144);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(140, 20);
            this.txtAddress.TabIndex = 9;
            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(105, 114);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(140, 20);
            this.txtRole.TabIndex = 8;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(105, 84);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(140, 20);
            this.txtName.TabIndex = 7;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(105, 54);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(140, 20);
            this.txtPassword.TabIndex = 6;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(105, 24);
            this.txtId.Name = "txtId";
            this.txtId.ReadOnly = true;
            this.txtId.Size = new System.Drawing.Size(140, 20);
            this.txtId.TabIndex = 5;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(24, 153);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(45, 13);
            this.lblAddress.TabIndex = 4;
            this.lblAddress.Text = "Address";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(24, 122);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(29, 13);
            this.lblRole.TabIndex = 3;
            this.lblRole.Text = "Role";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(24, 89);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(24, 58);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(53, 13);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Password";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(24, 24);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(18, 13);
            this.lblId.TabIndex = 0;
            this.lblId.Text = "ID";
            // 
            // dgvLoginInfo
            // 
            this.dgvLoginInfo.AllowUserToAddRows = false;
            this.dgvLoginInfo.AllowUserToDeleteRows = false;
            this.dgvLoginInfo.AutoGenerateColumns = false;
            this.dgvLoginInfo.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvLoginInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoginInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Password,
            this.Name,
            this.Role,
            this.Address});
            this.dgvLoginInfo.DataSource = this.loginInfoBindingSource;
            this.dgvLoginInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvLoginInfo.Location = new System.Drawing.Point(0, 209);
            this.dgvLoginInfo.Name = "dgvLoginInfo";
            this.dgvLoginInfo.ReadOnly = true;
            this.dgvLoginInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLoginInfo.Size = new System.Drawing.Size(655, 144);
            this.dgvLoginInfo.TabIndex = 1;
            this.dgvLoginInfo.DoubleClick += new System.EventHandler(this.dgvLoginInfo_DoubleClick);
            // 
            // loginInfoBindingSource
            // 
            this.loginInfoBindingSource.DataMember = "LoginInfo";
            this.loginInfoBindingSource.DataSource = this.bookShopDataSet;
            // 
            // bookShopDataSet
            // 
            this.bookShopDataSet.DataSetName = "BookShopDataSet";
            this.bookShopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginInfoTableAdapter
            // 
            this.loginInfoTableAdapter.ClearBeforeFill = true;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "User ID";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // Password
            // 
            this.Password.DataPropertyName = "Password";
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            // 
            // Name
            // 
            this.Name.DataPropertyName = "Name";
            this.Name.HeaderText = "User Name";
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            // 
            // Role
            // 
            this.Role.DataPropertyName = "Role";
            this.Role.HeaderText = "Role";
            this.Role.Name = "Role";
            this.Role.ReadOnly = true;
            // 
            // Address
            // 
            this.Address.DataPropertyName = "Address";
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            this.Address.ReadOnly = true;
            // 
            // AddUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 353);
            this.ControlBox = false;
            this.Controls.Add(this.dgvLoginInfo);
            this.Controls.Add(this.pnlAddUser);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddUser";
            this.Text = "AddUser";
            this.Load += new System.EventHandler(this.AddUser_Load);
            this.pnlAddUser.ResumeLayout(false);
            this.pnlAddUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoginInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAddUser;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Button btnAddUserShow;
        private System.Windows.Forms.Button btnAddUserDelete;
        private System.Windows.Forms.Button btnAddUserUpdate;
        private System.Windows.Forms.Button btnAddUserSave;
        private System.Windows.Forms.Button btnAddUserBack;
        private System.Windows.Forms.DataGridView dgvLoginInfo;
        private BookShopDataSet bookShopDataSet;
        private System.Windows.Forms.BindingSource loginInfoBindingSource;
        private BookShopDataSetTableAdapters.LoginInfoTableAdapter loginInfoTableAdapter;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button btnAddUserClearAll;
        private DataGridViewTextBoxColumn Id;
        private DataGridViewTextBoxColumn Password;
        private DataGridViewTextBoxColumn Name;
        private DataGridViewTextBoxColumn Role;
        private DataGridViewTextBoxColumn Address;

        public DataGridViewTextBoxColumn v { get; private set; }
    }
}