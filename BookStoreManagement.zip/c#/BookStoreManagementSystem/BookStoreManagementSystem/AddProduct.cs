﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BookStoreManagementSystem
{
    public partial class AddProduct : Form
    {
        private DataAccess Da { get; set; }
        public AddProduct()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            
        }

        private void btnAddProductBack_Click(object sender, EventArgs e)
        {
            new Admin().Show();
            this.Hide();
        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            
            //this.productTableAdapter.Fill(this.bookShopDataSet1.Product);
            this.PopulateGridView();
            AutoIdGenerate();
        }


        // Load all data
        private void PopulateGridView(string sql = "select * from Product;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                this.dgvProduct.AutoGenerateColumns = false; 
                this.dgvProduct.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        // Insert user
        private void btnAddProductSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtProductId.Text) ||
           string.IsNullOrWhiteSpace(txtProductName.Text) ||
           string.IsNullOrWhiteSpace(txtPrice.Text) ||
           string.IsNullOrWhiteSpace(txtQuantity.Text) ||
           string.IsNullOrWhiteSpace(txtCatagory.Text))
                {
                    MessageBox.Show("All fields are required.");
                    return;
                }
                string sql = $"insert into Product values( '{txtProductName.Text}', '{txtPrice.Text}', '{txtQuantity.Text}', '{txtCatagory.Text}')";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("Product added successfully");
                    this.PopulateGridView();
                   
                }
                else
                {
                    MessageBox.Show("Failed to add user");
                }
                this.ClearAll();
                this.PopulateGridView();
                this.AutoIdGenerate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding user: " + ex.Message);
            }



        }

        // Update user
        private void btnAddProductUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                string sql = $"update Product set ProductName = '{txtProductName.Text}', Price = '{txtPrice.Text}', Quantity = '{txtQuantity.Text}', Catagory = '{txtCatagory.Text}' where ProductId = '{txtProductId.Text}'";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("Product updated successfully");
                    this.PopulateGridView();
                    
                }
                else
                {
                    MessageBox.Show("Update failed");
                }
                this.ClearAll();
                this.PopulateGridView();
                this.AutoIdGenerate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating user: " + ex.Message);
            }
        }

        // Delete user

        private void btnAddProductDelete_Click(object sender, EventArgs e)
        {

            try
            {
                string sql = $"delete from Product where ProductId = '{txtProductId.Text}'";
                int count = this.Da.ExecuteDMLQuery(sql);
                if (count == 1)
                {
                    MessageBox.Show("Product deleted successfully");
                    
                    
                }
                else
                {
                    MessageBox.Show("Delete failed");
                }
                this.ClearAll();
                this.PopulateGridView();
                this.AutoIdGenerate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting user: " + ex.Message);
            }
        }
        // Show all user
        private void btnAddProductShow_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
            this.AutoIdGenerate();
        }

        // Load selected user from grid into textboxes
       
        private void dgvProduct_DoubleClick(object sender, EventArgs e)
        {
            this.txtProductId.Text = this.dgvProduct.CurrentRow.Cells[0].Value.ToString();
            this.txtProductName.Text = this.dgvProduct.CurrentRow.Cells[1].Value.ToString();
            this.txtPrice.Text = this.dgvProduct.CurrentRow.Cells[2].Value.ToString();
            this.txtQuantity.Text = this.dgvProduct.CurrentRow.Cells[3].Value.ToString();
            this.txtCatagory.Text = this.dgvProduct.CurrentRow.Cells[4].Value.ToString();
        }

        // Clear input fields
        private void ClearAll()
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtPrice.Clear();
            txtQuantity.Clear();
            txtCatagory.Clear();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            string sql = $"select * from Product where ProductId like '%{keyword}%' or ProductName like '%{keyword}%' or Catagory Like '%{keyword}%' or Price Like '%{keyword}%'";
            PopulateGridView(sql);
        }
        //AutoId generator
        private void AutoIdGenerate()
        {
            var query = "select max(ProductId) from Product ;";
            var dt = this.Da.ExecuteQueryTable(query);
            var oldProductId = dt.Rows[0][0];
            var num = Convert.ToInt32(oldProductId);
            var newProductId = ++num;
            this.txtProductId.Text = newProductId.ToString();
        }

        private void btnAddProductClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
            this.AutoIdGenerate();
        }
    }
}
