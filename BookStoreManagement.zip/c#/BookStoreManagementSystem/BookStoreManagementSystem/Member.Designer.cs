﻿namespace BookStoreManagementSystem
{
    partial class Member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Member));
            this.pnlMember = new System.Windows.Forms.Panel();
            this.lblDate = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.btnPaid = new System.Windows.Forms.Button();
            this.btnMemberDelete = new System.Windows.Forms.Button();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblSalesId = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtSalesId = new System.Windows.Forms.TextBox();
            this.btnMemberClear = new System.Windows.Forms.Button();
            this.btnAddCart = new System.Windows.Forms.Button();
            this.LblMemberSearch = new System.Windows.Forms.Label();
            this.txtMemberSearch = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblProductId = new System.Windows.Forms.Label();
            this.txtMemberQuantity = new System.Windows.Forms.TextBox();
            this.txtMemberPrice = new System.Windows.Forms.TextBox();
            this.txtMemberProductName = new System.Windows.Forms.TextBox();
            this.txtMemberProductId = new System.Windows.Forms.TextBox();
            this.btnMemberShowProduct = new System.Windows.Forms.Button();
            this.btnMemberBack = new System.Windows.Forms.Button();
            this.dgvProduct = new System.Windows.Forms.DataGridView();
            this.productIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.catagoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookShopDataSet1 = new BookStoreManagementSystem.BookShopDataSet1();
            this.productTableAdapter = new BookStoreManagementSystem.BookShopDataSet1TableAdapters.ProductTableAdapter();
            this.dgvCart = new System.Windows.Forms.DataGridView();
            this.ProductId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMember.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMember
            // 
            this.pnlMember.Controls.Add(this.lblDate);
            this.pnlMember.Controls.Add(this.dateTimePicker2);
            this.pnlMember.Controls.Add(this.btnPaid);
            this.pnlMember.Controls.Add(this.btnMemberDelete);
            this.pnlMember.Controls.Add(this.txtTotalAmount);
            this.pnlMember.Controls.Add(this.lblTotalAmount);
            this.pnlMember.Controls.Add(this.lblCustomerName);
            this.pnlMember.Controls.Add(this.lblSalesId);
            this.pnlMember.Controls.Add(this.txtCustomerName);
            this.pnlMember.Controls.Add(this.txtSalesId);
            this.pnlMember.Controls.Add(this.btnMemberClear);
            this.pnlMember.Controls.Add(this.btnAddCart);
            this.pnlMember.Controls.Add(this.LblMemberSearch);
            this.pnlMember.Controls.Add(this.txtMemberSearch);
            this.pnlMember.Controls.Add(this.lblProductName);
            this.pnlMember.Controls.Add(this.lblPrice);
            this.pnlMember.Controls.Add(this.lblQuantity);
            this.pnlMember.Controls.Add(this.lblProductId);
            this.pnlMember.Controls.Add(this.txtMemberQuantity);
            this.pnlMember.Controls.Add(this.txtMemberPrice);
            this.pnlMember.Controls.Add(this.txtMemberProductName);
            this.pnlMember.Controls.Add(this.txtMemberProductId);
            this.pnlMember.Controls.Add(this.btnMemberShowProduct);
            this.pnlMember.Controls.Add(this.btnMemberBack);
            this.pnlMember.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMember.Location = new System.Drawing.Point(0, 0);
            this.pnlMember.Name = "pnlMember";
            this.pnlMember.Size = new System.Drawing.Size(752, 174);
            this.pnlMember.TabIndex = 0;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(543, 65);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 28;
            this.lblDate.Text = "Date";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(585, 58);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(155, 20);
            this.dateTimePicker2.TabIndex = 27;
            // 
            // btnPaid
            // 
            this.btnPaid.BackColor = System.Drawing.Color.GreenYellow;
            this.btnPaid.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaid.Location = new System.Drawing.Point(599, 138);
            this.btnPaid.Name = "btnPaid";
            this.btnPaid.Size = new System.Drawing.Size(141, 29);
            this.btnPaid.TabIndex = 24;
            this.btnPaid.Text = "Paid";
            this.btnPaid.UseVisualStyleBackColor = false;
            this.btnPaid.Click += new System.EventHandler(this.btnPaid_Click);
            // 
            // btnMemberDelete
            // 
            this.btnMemberDelete.BackColor = System.Drawing.Color.Red;
            this.btnMemberDelete.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberDelete.Location = new System.Drawing.Point(432, 138);
            this.btnMemberDelete.Name = "btnMemberDelete";
            this.btnMemberDelete.Size = new System.Drawing.Size(141, 29);
            this.btnMemberDelete.TabIndex = 23;
            this.btnMemberDelete.Text = "Delete";
            this.btnMemberDelete.UseVisualStyleBackColor = false;
            this.btnMemberDelete.Click += new System.EventHandler(this.btnMemberDelete_Click);
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtTotalAmount.Location = new System.Drawing.Point(585, 84);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(155, 20);
            this.txtTotalAmount.TabIndex = 22;
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Location = new System.Drawing.Point(503, 91);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(70, 13);
            this.lblTotalAmount.TabIndex = 21;
            this.lblTotalAmount.Text = "Total Amount";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(491, 36);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(82, 13);
            this.lblCustomerName.TabIndex = 20;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // lblSalesId
            // 
            this.lblSalesId.AutoSize = true;
            this.lblSalesId.Location = new System.Drawing.Point(526, 13);
            this.lblSalesId.Name = "lblSalesId";
            this.lblSalesId.Size = new System.Drawing.Size(47, 13);
            this.lblSalesId.TabIndex = 19;
            this.lblSalesId.Text = "Sales ID";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(585, 32);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(155, 20);
            this.txtCustomerName.TabIndex = 18;
            // 
            // txtSalesId
            // 
            this.txtSalesId.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtSalesId.Location = new System.Drawing.Point(585, 6);
            this.txtSalesId.Name = "txtSalesId";
            this.txtSalesId.Size = new System.Drawing.Size(155, 20);
            this.txtSalesId.TabIndex = 17;
            // 
            // btnMemberClear
            // 
            this.btnMemberClear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMemberClear.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberClear.Location = new System.Drawing.Point(263, 75);
            this.btnMemberClear.Name = "btnMemberClear";
            this.btnMemberClear.Size = new System.Drawing.Size(141, 29);
            this.btnMemberClear.TabIndex = 15;
            this.btnMemberClear.Text = "Clear";
            this.btnMemberClear.UseVisualStyleBackColor = false;
            this.btnMemberClear.Click += new System.EventHandler(this.btnMemberClear_Click);
            // 
            // btnAddCart
            // 
            this.btnAddCart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddCart.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCart.Location = new System.Drawing.Point(263, 110);
            this.btnAddCart.Name = "btnAddCart";
            this.btnAddCart.Size = new System.Drawing.Size(141, 29);
            this.btnAddCart.TabIndex = 14;
            this.btnAddCart.Text = "Add Cart";
            this.btnAddCart.UseVisualStyleBackColor = false;
            this.btnAddCart.Click += new System.EventHandler(this.btnAddCart_Click);
            // 
            // LblMemberSearch
            // 
            this.LblMemberSearch.AutoSize = true;
            this.LblMemberSearch.Location = new System.Drawing.Point(206, 152);
            this.LblMemberSearch.Name = "LblMemberSearch";
            this.LblMemberSearch.Size = new System.Drawing.Size(41, 13);
            this.LblMemberSearch.TabIndex = 13;
            this.LblMemberSearch.Text = "Search";
            // 
            // txtMemberSearch
            // 
            this.txtMemberSearch.Location = new System.Drawing.Point(263, 145);
            this.txtMemberSearch.Name = "txtMemberSearch";
            this.txtMemberSearch.Size = new System.Drawing.Size(141, 20);
            this.txtMemberSearch.TabIndex = 12;
            this.txtMemberSearch.TextChanged += new System.EventHandler(this.txtMemberSearch_TextChanged);
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(12, 29);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(75, 13);
            this.lblProductName.TabIndex = 10;
            this.lblProductName.Text = "Product Name";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(12, 55);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 9;
            this.lblPrice.Text = "Price";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(12, 84);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(46, 13);
            this.lblQuantity.TabIndex = 8;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblProductId
            // 
            this.lblProductId.AutoSize = true;
            this.lblProductId.Location = new System.Drawing.Point(12, 9);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new System.Drawing.Size(53, 13);
            this.lblProductId.TabIndex = 7;
            this.lblProductId.Text = "ProductId";
            // 
            // txtMemberQuantity
            // 
            this.txtMemberQuantity.Location = new System.Drawing.Point(106, 81);
            this.txtMemberQuantity.Name = "txtMemberQuantity";
            this.txtMemberQuantity.Size = new System.Drawing.Size(141, 20);
            this.txtMemberQuantity.TabIndex = 5;
            // 
            // txtMemberPrice
            // 
            this.txtMemberPrice.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtMemberPrice.Location = new System.Drawing.Point(106, 55);
            this.txtMemberPrice.Name = "txtMemberPrice";
            this.txtMemberPrice.ReadOnly = true;
            this.txtMemberPrice.Size = new System.Drawing.Size(141, 20);
            this.txtMemberPrice.TabIndex = 4;
            // 
            // txtMemberProductName
            // 
            this.txtMemberProductName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtMemberProductName.Location = new System.Drawing.Point(106, 29);
            this.txtMemberProductName.Name = "txtMemberProductName";
            this.txtMemberProductName.ReadOnly = true;
            this.txtMemberProductName.Size = new System.Drawing.Size(141, 20);
            this.txtMemberProductName.TabIndex = 3;
            // 
            // txtMemberProductId
            // 
            this.txtMemberProductId.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtMemberProductId.Location = new System.Drawing.Point(106, 3);
            this.txtMemberProductId.Name = "txtMemberProductId";
            this.txtMemberProductId.ReadOnly = true;
            this.txtMemberProductId.Size = new System.Drawing.Size(141, 20);
            this.txtMemberProductId.TabIndex = 2;
            // 
            // btnMemberShowProduct
            // 
            this.btnMemberShowProduct.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberShowProduct.Location = new System.Drawing.Point(84, 128);
            this.btnMemberShowProduct.Name = "btnMemberShowProduct";
            this.btnMemberShowProduct.Size = new System.Drawing.Size(100, 37);
            this.btnMemberShowProduct.TabIndex = 1;
            this.btnMemberShowProduct.Text = "Show Product";
            this.btnMemberShowProduct.UseVisualStyleBackColor = true;
            this.btnMemberShowProduct.Click += new System.EventHandler(this.btnMemberShowProduct_Click);
            // 
            // btnMemberBack
            // 
            this.btnMemberBack.BackColor = System.Drawing.Color.Red;
            this.btnMemberBack.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberBack.Location = new System.Drawing.Point(3, 128);
            this.btnMemberBack.Name = "btnMemberBack";
            this.btnMemberBack.Size = new System.Drawing.Size(75, 37);
            this.btnMemberBack.TabIndex = 0;
            this.btnMemberBack.Text = "Back";
            this.btnMemberBack.UseVisualStyleBackColor = false;
            this.btnMemberBack.Click += new System.EventHandler(this.btnMemberBack_Click);
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowUserToAddRows = false;
            this.dgvProduct.AllowUserToDeleteRows = false;
            this.dgvProduct.AutoGenerateColumns = false;
            this.dgvProduct.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIdDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.catagoryDataGridViewTextBoxColumn});
            this.dgvProduct.DataSource = this.productBindingSource;
            this.dgvProduct.Dock = System.Windows.Forms.DockStyle.Left;
            this.dgvProduct.Location = new System.Drawing.Point(0, 174);
            this.dgvProduct.Name = "dgvProduct";
            this.dgvProduct.ReadOnly = true;
            this.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProduct.Size = new System.Drawing.Size(404, 150);
            this.dgvProduct.TabIndex = 1;
            this.dgvProduct.DoubleClick += new System.EventHandler(this.dgvProduct_DoubleClick);
            // 
            // productIdDataGridViewTextBoxColumn
            // 
            this.productIdDataGridViewTextBoxColumn.DataPropertyName = "ProductId";
            this.productIdDataGridViewTextBoxColumn.HeaderText = "ProductId";
            this.productIdDataGridViewTextBoxColumn.Name = "productIdDataGridViewTextBoxColumn";
            this.productIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.productIdDataGridViewTextBoxColumn.Width = 60;
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "ProductName";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "ProductName";
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            this.productNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 50;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            this.quantityDataGridViewTextBoxColumn.Width = 50;
            // 
            // catagoryDataGridViewTextBoxColumn
            // 
            this.catagoryDataGridViewTextBoxColumn.DataPropertyName = "Catagory";
            this.catagoryDataGridViewTextBoxColumn.HeaderText = "Catagory";
            this.catagoryDataGridViewTextBoxColumn.Name = "catagoryDataGridViewTextBoxColumn";
            this.catagoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.bookShopDataSet1;
            // 
            // bookShopDataSet1
            // 
            this.bookShopDataSet1.DataSetName = "BookShopDataSet1";
            this.bookShopDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // dgvCart
            // 
            this.dgvCart.AllowUserToAddRows = false;
            this.dgvCart.AllowUserToDeleteRows = false;
            this.dgvCart.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvCart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCart.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductId,
            this.ProductName,
            this.Quantity,
            this.TotalPrice});
            this.dgvCart.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvCart.Location = new System.Drawing.Point(401, 174);
            this.dgvCart.Name = "dgvCart";
            this.dgvCart.ReadOnly = true;
            this.dgvCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCart.Size = new System.Drawing.Size(351, 150);
            this.dgvCart.TabIndex = 2;
            // 
            // ProductId
            // 
            this.ProductId.HeaderText = "Product Id";
            this.ProductId.Name = "ProductId";
            this.ProductId.ReadOnly = true;
            this.ProductId.Width = 50;
            // 
            // ProductName
            // 
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Width = 60;
            // 
            // TotalPrice
            // 
            this.TotalPrice.HeaderText = "Total Price";
            this.TotalPrice.Name = "TotalPrice";
            this.TotalPrice.ReadOnly = true;
            // 
            // Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 324);
            this.Controls.Add(this.dgvCart);
            this.Controls.Add(this.dgvProduct);
            this.Controls.Add(this.pnlMember);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Member";
            this.Text = "\'";
            this.Load += new System.EventHandler(this.Member_Load);
            this.pnlMember.ResumeLayout(false);
            this.pnlMember.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookShopDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMember;
        private System.Windows.Forms.Button btnMemberBack;
        private System.Windows.Forms.Button btnMemberShowProduct;
        private System.Windows.Forms.DataGridView dgvProduct;
        private BookShopDataSet1 bookShopDataSet1;
        private System.Windows.Forms.BindingSource productBindingSource;
        private BookShopDataSet1TableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn catagoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtMemberQuantity;
        private System.Windows.Forms.TextBox txtMemberPrice;
        private System.Windows.Forms.TextBox txtMemberProductName;
        private System.Windows.Forms.TextBox txtMemberProductId;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblProductId;
        private System.Windows.Forms.Label LblMemberSearch;
        private System.Windows.Forms.TextBox txtMemberSearch;
        private System.Windows.Forms.Button btnAddCart;
        private System.Windows.Forms.Button btnMemberClear;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblSalesId;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtSalesId;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.DataGridView dgvCart;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPrice;
        private System.Windows.Forms.Button btnPaid;
        private System.Windows.Forms.Button btnMemberDelete;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
    }
}