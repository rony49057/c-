﻿using System;
using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    public partial class ResetPassword : Form
    {
        private DataAccess Da { get; set; }

        public ResetPassword()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void btnResetClear_Click(object sender, EventArgs e)
        {
            txtNewPass.Clear();
            txtResetId.Clear();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            string resetPass=txtNewPass.Text;
            string resetId=txtResetId.Text;
            try
            {
                // Make sure you are updating the correct table and columns
                string sql = $"UPDATE LoginInfo SET Password = '{txtNewPass.Text}' WHERE Id = '{txtResetId.Text}'";
                int count = this.Da.ExecuteDMLQuery(sql);

                if (count == 1)
                {
                    MessageBox.Show("Password updated successfully");
                    this.ClearAll();
                }
                else
                {
                    MessageBox.Show($"No user found with ID '{resetId}'.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating user: " + ex.Message);
            }
        }

        private void ClearAll()
        {
            txtNewPass.Clear();
            txtResetId.Clear();
        }
    }
}
