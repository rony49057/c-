﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStoreManagementSystem
{
    public partial class Admin : Form
    {
        private DataAccess Da { get; set; }
        public Admin()
        {
            InitializeComponent();
            this.FormClosing -= Admin_FormClosed;
            this.FormClosing += Admin_FormClosed;
            this.Da = new DataAccess(); // Initialize DataAccess
            
           // this.AutoIdGenerate();
        }

        private void Admin_FormClosed(object sender, FormClosingEventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show(@"Are you want to exit?", "Exit Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);



                if (result == DialogResult.OK)
                {
                    Application.Exit(); // Cancel the close
                }

                else 
                {
                   e.Cancel = true;
                    return;
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show("Error during closing: " + ex.Message);
            }
        } 

        private void btnAdminBack_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            
           // this.Close();
           
            this.Hide();
           // new Login().Show();

        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
             
            new AddUser().Show();
            this.Hide();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            new AddProduct().Show();
            this.Hide();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            
            this.salesInfoTableAdapter.Fill(this.bookShopDataSet2.SalesInfo);
            this.PopulateGridView();
        }


        // Load all data
        private void PopulateGridView(string sql = "select * from SalesInfo;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                this.dataGridView1.AutoGenerateColumns = false; // Set to false if you added columns manually
                this.dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

          
            
        }

        private void txtAdminSearch_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtAdminSearch.Text.Trim();
            string sql = $"select * from SalesInfo where SalesId like '%{keyword}%' or ProductId like '%{keyword}%' or SalesDate Like '%{keyword}%' or CustomerName Like '%{keyword}%' ";
            PopulateGridView(sql);
        }
    }
}
